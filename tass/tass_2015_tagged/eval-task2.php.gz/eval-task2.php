<?php
function evalTask2($qrel, $run, $checkdata, &$result) {
  $QREL = array();
  $DATA = array();
  $CONFUSION = array();

  if(!($fd = fopen($qrel, 'r'))) {
    echo 'Cannot open qrel file.'."\n";
    return false;
  }
  $qrel_size = 0;
  $REPEATED = array();
  while(!feof($fd)) {
    $line = trim(fgets($fd), "\n\r");
    if(preg_match('/^(.+?)\t(.+?)\t(.+?)$/', $line, $fields)) {
      $qrel_size++;
      $id = $fields[1];
      $aspect = $fields[2];
      $value = $fields[3];
      $REPEATED[$id.'-'.$aspect] = (!isset($REPEATED[$id.'-'.$aspect]) ? 1 : $REPEATED[$id.'-'.$aspect]+1);
      $QREL[$id.'-'.$aspect.'#'.$REPEATED[$id.'-'.$aspect]] = $aspect.'-'.$value;
    } elseif(!empty($line)) {
      echo 'Wrong qrel file format: "'.$line.'".'."\n";
      return false;
    }
  }
  fclose($fd);
  if(!($fd = fopen($run, 'r'))) {
    echo 'Cannot open run file.'."\n";
    return false;
  }
  $data_size = 0;
  $REPEATED = array();
  while(!feof($fd)) {
    $line = trim(fgets($fd), "\n\r");
    if(preg_match('/^(.+?)\t(.+?)\t(.+?)$/', $line, $fields)) {
      $id = $fields[1];
      $aspect = $fields[2];
      $value = $fields[3];
      $REPEATED[$id.'-'.$aspect] = (!isset($REPEATED[$id.'-'.$aspect]) ? 1 : $REPEATED[$id.'-'.$aspect]+1);
      if(isset($QREL[$id.'-'.$aspect.'#'.$REPEATED[$id.'-'.$aspect]])) {
        $DATA[$id.'-'.$aspect.'#'.$REPEATED[$id.'-'.$aspect]] = $aspect.'-'.$value;
        $data_size++;
      } elseif($checkdata) {
        echo 'Ignoring unknown instance id: "'.$id.'", aspect: "'.$aspect.'", appearance: '.$REPEATED[$id.'-'.$aspect].'.'."\n";
        //return false;
      }
    } elseif(!empty($line)) {
      echo 'Wrong run file format: "'.$line.'".'."\n";
      return false;
    }
  }
  fclose($fd);

  $aTP = array();
  $aFP = array();
  $aFN = array();
  foreach($QREL as $id => $valueqrel) {
    if(isset($DATA[$id])) 
      $value = $DATA[$id];
    else
      $value = '?';
    if($valueqrel==$value)
      $aTP[$valueqrel] = (isset($aTP[$valueqrel]) ? $aTP[$valueqrel]+1 : 1);
    else {
      $aFP[$value] = (isset($aFP[$value]) ? $aFP[$value]+1 : 1);
      $aFN[$valueqrel] = (isset($aFN[$valueqrel]) ? $aFN[$valueqrel]+1 : 1);
    }
    if(!isset($CONFUSION[$valueqrel])) 
      $CONFUSION[$valueqrel] = array($value => 1);
    elseif(!isset($CONFUSION[$valueqrel][$value]))
      $CONFUSION[$valueqrel][$value] = 1;
    else
      $CONFUSION[$valueqrel][$value]++;
  }
  $tp = 0;
  $fp = 0;
  $fn = 0;
  foreach($CONFUSION as $valueqrel => $_a) {
    if(!isset($aTP[$valueqrel]))
      $aTP[$valueqrel] = 0;
    if(!isset($aFP[$valueqrel]))
      $aFP[$valueqrel] = 0;
    if(!isset($aFN[$valueqrel]))
      $aFN[$valueqrel] = 0;
    $tp += $aTP[$valueqrel];
    $fp += $aFP[$valueqrel];
    $fn += $aFN[$valueqrel];
  }
  $a = $tp/$qrel_size;
  $mip = $tp/($tp+$fp);
  $mir = $tp/($tp+$fn);
  $mif1 = ($mip+$mir==0 ? 0 : 2*$mip*$mir/($mip+$mir));
  $aP = array();
  $aR = array();
  $aF1 = array();
  $map = 0;
  $mar = 0;
  $maf1 = 0;
  foreach($CONFUSION as $valueqrel => $_a) {
    $aP[$valueqrel] = ($aTP[$valueqrel]+$aFP[$valueqrel]==0 ? 0 : $aTP[$valueqrel]/($aTP[$valueqrel]+$aFP[$valueqrel]));
    $aR[$valueqrel] = ($aTP[$valueqrel]+$aFN[$valueqrel]==0 ? 0 : $aTP[$valueqrel]/($aTP[$valueqrel]+$aFN[$valueqrel]));
    $aF1[$valueqrel] = ($aP[$valueqrel]+$aR[$valueqrel]==0 ? 0 : 2*$aP[$valueqrel]*$aR[$valueqrel]/($aP[$valueqrel]+$aR[$valueqrel]));
    $map += $aP[$valueqrel];
    $mar += $aR[$valueqrel];
  }
  $map /= sizeof($CONFUSION);
  $mar /= sizeof($CONFUSION);
  $maf1 = ($map+$mar==0 ? 0 : 2*$map*$mar/($map+$mar));

  $result = array('a' => number_format($a, 3),
                  'p' => number_format($map, 3),
                  'r' => number_format($mar, 3),
                  'f1' => number_format($maf1, 3),
                  'info' => '');
  $result['info'] = $qrel_size.' aspects in qrel, '.$data_size.' aspects in run.'."\n".
                    "\n".
                    'Accuracy: '.number_format($a, 3)."\n".
                    "\n".
                    'Confusion matrix'."\n".
                    'Actual'."\t".'Pred'."\t".'#'."\n";
  ksort($CONFUSION);
  foreach($CONFUSION as $k1 => $v1) {
    foreach($v1 as $k2 => $v2) 
      $result['info'] .= $k1."\t".$k2."\t".$v2."\n";
  }
  $result['info'] .= "\n".
                     'Category evaluation'."\n".
                     'Cat'."\t".'P'."\t".'R'."\t".'F1'."\n";
  foreach($CONFUSION as $valueqrel => $_a) 
    $result['info'] .= $valueqrel."\t".number_format($aP[$valueqrel], 3)."\t".number_format($aR[$valueqrel], 3)."\t".number_format($aF1[$valueqrel], 3)."\n";
  $result['info'] .= "\n".
                     'Macroaveraged Precision: '.number_format($map, 3)."\n".
                     'Macroaveraged Recall: '.number_format($mar, 3)."\n".
                     'Macroaveraged F1: '.number_format($maf1, 3)."\n";
  return $result;
} // evalTask2

if(isset($argv)) {
  if(sizeof($argv)-1!=2) {
    echo 'Usage: php eval-task2.php <qrel_file> <run_file>'."\n";
    exit(1);
  }
  if(evalTask2($argv[1], $argv[2], true, $result))
    print_r($result);
}
?>
